var searchData=
[
  ['dbmanager',['DBManager',['../interface_d_b_manager.html',1,'']]],
  ['dbmanager_28_29',['DBManager()',['../category_d_b_manager_07_08.html',1,'']]]
];

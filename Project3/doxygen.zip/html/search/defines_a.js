var searchData=
[
  ['key_5fcache_5fblock_5fsize',['KEY_CACHE_BLOCK_SIZE',['../my__global_8h.html#a74c44a43e9b10db08ba1ce9e7d4218c9',1,'my_global.h']]],
  ['key_5fcache_5fsize',['KEY_CACHE_SIZE',['../my__global_8h.html#a7712b9a55292db9b4728778c79b08fa5',1,'my_global.h']]],
  ['key_5fread_5fused',['KEY_READ_USED',['../my__base_8h.html#adb2972cbc5d61c771fcd6a02acbdb874',1,'my_base.h']]]
];

var searchData=
[
  ['bookdetails',['BookDetails',['../interface_book_details.html',1,'']]],
  ['bookdetails_28_29',['BookDetails()',['../category_book_details_07_08.html',1,'']]],
  ['borrowdetailviewcontroller',['BorrowDetailViewController',['../interface_borrow_detail_view_controller.html',1,'']]],
  ['borrowdetailviewcontroller_28_29',['BorrowDetailViewController()',['../category_borrow_detail_view_controller_07_08.html',1,'']]]
];

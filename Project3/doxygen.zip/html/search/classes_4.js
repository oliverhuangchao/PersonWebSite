var searchData=
[
  ['fileinfo',['fileinfo',['../structfileinfo.html',1,'']]]
];

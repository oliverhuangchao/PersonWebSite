var searchData=
[
  ['o_5fbinary',['O_BINARY',['../config-win_8h.html#a36fa9b2e726512bc17a7a6d3e39002be',1,'O_BINARY():&#160;config-win.h'],['../my__global_8h.html#a36fa9b2e726512bc17a7a6d3e39002be',1,'O_BINARY():&#160;my_global.h']]],
  ['o_5fnofollow',['O_NOFOLLOW',['../my__global_8h.html#a82d4d551b214905742c9e045185d352a',1,'my_global.h']]],
  ['o_5fshare',['O_SHARE',['../my__global_8h.html#a3c4b91fe97cfdd23c9ab2950be54011b',1,'my_global.h']]],
  ['o_5fshort_5flived',['O_SHORT_LIVED',['../config-win_8h.html#aed912e7362f94922fb0978510dd2496d',1,'O_SHORT_LIVED():&#160;config-win.h'],['../my__global_8h.html#aed912e7362f94922fb0978510dd2496d',1,'O_SHORT_LIVED():&#160;my_global.h']]],
  ['o_5ftemporary',['O_TEMPORARY',['../config-win_8h.html#afa73d851c2ac9d5eb925495196af6c0d',1,'O_TEMPORARY():&#160;config-win.h'],['../my__global_8h.html#afa73d851c2ac9d5eb925495196af6c0d',1,'O_TEMPORARY():&#160;my_global.h']]],
  ['offset',['OFFSET',['../my__global_8h.html#ac5766e042312bc301bcb806975d275c2',1,'my_global.h']]],
  ['offset_5fto_5fepoch',['OFFSET_TO_EPOCH',['../config-win_8h.html#a013fe715be96eb5b52345070e7a7f0e6',1,'config-win.h']]],
  ['offsetof',['offsetof',['../my__global_8h.html#a276e8a32e0bbf024aadd9420b8f2d3b3',1,'my_global.h']]],
  ['on_5fupdate_5fnow_5fflag',['ON_UPDATE_NOW_FLAG',['../mysql__com_8h.html#a9c58a417db90a114db37e0d36f661418',1,'mysql_com.h']]],
  ['once_5falloc_5finit',['ONCE_ALLOC_INIT',['../my__global_8h.html#a4b8ee8208b379df1ce5953d0922116c5',1,'my_global.h']]],
  ['only_5fkill_5fquery',['ONLY_KILL_QUERY',['../mysql__com_8h.html#aff681008e30f507179af6585629be2d2',1,'mysql_com.h']]],
  ['opt_5fno_5frows',['OPT_NO_ROWS',['../my__base_8h.html#a4353ec9d4d98cf506b1502248c40ed95',1,'my_base.h']]],
  ['orig_5fcaller_5finfo',['ORIG_CALLER_INFO',['../my__sys_8h.html#a27c82ce6b0a2b89c4562ef86c5745e71',1,'my_sys.h']]],
  ['os_5ffile_5flimit',['OS_FILE_LIMIT',['../config-win_8h.html#a6ed6a6dcab36925369ee5906fb99008f',1,'OS_FILE_LIMIT():&#160;config-win.h'],['../my__global_8h.html#a6ed6a6dcab36925369ee5906fb99008f',1,'OS_FILE_LIMIT():&#160;my_global.h']]]
];

var searchData=
[
  ['xml_5fstack_5fst',['xml_stack_st',['../structxml__stack__st.html',1,'']]]
];

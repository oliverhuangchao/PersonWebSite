var searchData=
[
  ['zerofill_5fflag',['ZEROFILL_FLAG',['../mysql__com_8h.html#a0e5559ab79365f739055868042f5a081',1,'mysql_com.h']]]
];
